package com.itwill.shop.user;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class UserDaoImplMyBatisTest {

	@BeforeEach
	void setUp() throws Exception {
	}

	@Test
	void testUserDaoImplMyBatis() {
		fail("Not yet implemented");
	}

	@Test
	void testUpdate() {
		fail("Not yet implemented");
	}

	@Test
	void testFindUser() {
		fail("Not yet implemented");
	}

	@Test
	void testFindUserList() {
		fail("Not yet implemented");
	}

	@Test
	void testInsert() {
		fail("Not yet implemented");
	}

	@Test
	void testDelete() {
		fail("Not yet implemented");
	}

	@Test
	void testCountByUserId() {
		fail("Not yet implemented");
	}

}
