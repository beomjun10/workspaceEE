package com.itwill.shop.common;

import javax.sql.DataSource;

public class DataSourceFactoryTestMain {

	public static void main(String[] args)throws Exception {
		DataSource ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		ds=DataSourceFactory.getDataSource();
		System.out.println(ds);
		
	}

}
