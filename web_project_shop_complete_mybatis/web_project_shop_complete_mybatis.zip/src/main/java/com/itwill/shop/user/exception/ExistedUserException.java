package com.itwill.shop.user.exception;

public class ExistedUserException extends Exception {
	public ExistedUserException() {
		// TODO Auto-generated constructor stub
	}
	public ExistedUserException(String msg) {
		super(msg);
	}
}
