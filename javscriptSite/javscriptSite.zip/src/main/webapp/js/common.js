/**
 * common.js

 */
function isSame(v1,v2){
	if(v1===v2){
		return true;
	}
	return false;
}