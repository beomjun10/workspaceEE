package com.itwill.guest;

import java.util.List;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class GuestDaoMyBatis {
	public static final String NAMESPACE = "com.itwill.guest.mapper.GuestMapper.";
	private SqlSessionFactory sqlSessionFactory;

	public GuestDaoMyBatis() throws Exception {
		this.sqlSessionFactory = 
				new SqlSessionFactoryBuilder()
				.build(Resources.getResourceAsStream("mybatis-config.xml"));
	}

	public int insert(Guest guest) throws Exception {
		return 0;
	}

	public Guest findByNo(int no) throws Exception {
		return null;
	}

	public List<Guest> findAll() throws Exception {
		List<Guest> guestList = null;
		return guestList;
	}

	public int update(Guest guest) throws Exception {
		return 0;
	}

	public int delete(int no) throws Exception {
		return 0;
	}

}
