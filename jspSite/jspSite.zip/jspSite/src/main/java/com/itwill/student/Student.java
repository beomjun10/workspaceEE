package com.itwill.student;

public class Student {

}
